package ALCSynthesis.Visualization;

import Synthesis.RefineSynchronize;
import Synthesis.GenerateALCs;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.swing.JPanel;

public class VisualizeALC extends JPanel
 {
   public static ArrayList<String> status=new ArrayList<String>();
   public static ArrayList<Map<List<String>, List<Integer>>> myList = new ArrayList<Map<List<String>, List<Integer>>>();
   public static Map<List<String>, List<Integer>> map;
   public static HashMap<Integer, Integer> map1= new HashMap<Integer,Integer>();
   public static String dependency,SyncSt,sourceobject,destinationobject,source,destination,id,state,PreviousState;
   public static HashMap<Integer, Integer> Dimension=new LinkedHashMap<Integer, Integer>() ;
   public static int maxWidth,totalHeight;
   public static Document document;
   public static Node Artifact=null;
   public static NodeList SyncObj=null;
   public static int x=200,y=100,w=100,h=50, x1=0,y1=0,ymax=0,xmax=0, extra=0, ymin=0; 
   public static File file ;
   
   public VisualizeALC()
    {
      maxWidth    = 20000;
      totalHeight = 20000;
    }
   public Dimension getPreferredSize()
    {
      return new Dimension(maxWidth, totalHeight);
    }
    public static File Return(File f)
     {
         RefineSynchronize fil=new RefineSynchronize();
         f=fil.ReturnFile();
         return f;
     }
     public void paintComponent(Graphics g)
     {  
       super.paintComponent(g);
       super.setBackground(Color.yellow);
       drawing(g);
      }
    public static void drawing (Graphics g)
     {  
      x=50;
      y=200;
      try
        {
          File fXmlFile=Return(file);
          DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
          DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
          Document doc = dBuilder.parse(fXmlFile);
          NodeList ALCList= doc.getElementsByTagName("ArtifactLifeCycles");
          NodeList syn=doc.getElementsByTagName("Synchronization");
          if(syn.getLength()>0)
           {
             SyncObj=syn.item(0).getChildNodes();
           }
          Node ALC = ALCList.item(0);
          Graphics2D g2d = (Graphics2D) g;
          g2d.setFont(new Font("TimesRoman", Font.BOLD, 18)); 
          BasicStroke bs1 = new BasicStroke(2, BasicStroke.CAP_BUTT,
          BasicStroke.JOIN_BEVEL);
          g2d.setStroke(bs1);
          for(int q=0;q<ALC.getChildNodes().getLength();q++)
           {
             Artifact=ALC.getChildNodes().item(q);
             if(Artifact.getNodeType()==Node.ELEMENT_NODE&&!Artifact.getNodeName().equalsIgnoreCase("Synchronization"))
              {
               PreviousState="XXXX";
               map = new HashMap<List<String>, List<Integer>>();
               x=200;
               g.setFont(new Font("TimesRoman", Font.BOLD, 18)); 
               SetString.setString(g,Artifact.getNodeName(),w,h,x,y-80);
               g.setFont(new Font("TimesRoman", Font.BOLD, 15)); 
               g.drawOval(x, y, w/2, h);
               g.drawLine(x+w/2, y+h/2, x+w, y+h/2);
               g.drawLine(x+w-10, y+h/2+10,x+w, y+h/2);
               g.drawLine(x+w-10, y+h/2-10,x+w, y+h/2);
               x =x+w;
               status.clear();
               y1=y;
               ymax=y1;
               ymin=y;
               LC(g,Artifact, x,y);
               g.drawLine(xmax, y+h/2, xmax+w/2, y+h/2);
               g.drawLine(xmax+w/2-10, y+h/2+10, xmax+w/2, y+h/2);
               g.drawLine(xmax+w/2-10, y+h/2-10, xmax+w/2, y+h/2);
               g.drawOval(xmax+w/2, y, w/2, h);
               g.fillOval(xmax+w/2, y, w/2, h);
               int ydim=0;
               if(ymax>ymin)
                {
                  ydim=ymax-ymin;
                }
               else if(ymax==ymin)
                {
                  ydim=h+h/2;
                }
                g.drawRect(x-w-20, ymin-50,xmax-w/2, ydim+20);
                y=ymax+4*h; 
                if(Artifact.getNodeName().equalsIgnoreCase("Products"))
                 {
                   y=y-2*h;
                 }
                 xmax=0;             
                 Dimension.clear();
                 myList.add(map);
               }
            }
          SynchronizeALC(myList,SyncObj,g);
        }
      catch(Exception e) 
        {
          e.printStackTrace();
        }
    }
     
    public static void LC(Graphics g,Node n, int x1,int y1)
     {
       for(int i=0;i<n.getChildNodes().getLength();i++)
        {
         Node c=n.getChildNodes().item(i);
         if(c.getNodeType()==Node.ELEMENT_NODE)
          {
            if(c.getNodeName().equalsIgnoreCase("State"))
              {
                extra=Construct(g,c,x1,y1);
                x1=extra;
                 if(xmax<x1)
                 {
                   xmax=x1;
                 }
              }
            else if(c.getNodeName().equalsIgnoreCase("gateway"))
              {
                status.clear();
                status=CheckStates(g,c);
                if(status.size()>0)
                 {
                   drawGatewayShape(g, x1, y1); 
                   if(c.getAttributes().getNamedItem("name").getNodeValue().equalsIgnoreCase("xorsplit"))
                     {
                       SetString.setString(g,"XOR", w,h, x1, y1);
                     }
                   else if(c.getAttributes().getNamedItem("name").getNodeValue().equalsIgnoreCase("andsplit"))
                     { 
                       SetString.setString(g,"AND", w,h, x1, y1);
                     }
                     //draw horizontal line after gateway node
                     g.drawLine(x1+w, y1+h/2, x1+w+w/4, y1+h/2);
                     g.drawLine(x1+w+w/4-10, y1+h/2-10, x1+w+w/4, y1+h/2);
                     g.drawLine(x1+w+w/4-10, y1+h/2+10, x1+w+w/4, y1+h/2);
                     y1=y1-h;
                     if(ymin>y1)
                      {
                        ymin=y1;
                      }
                     x1=x1+w+w/2;
                      if(xmax<x1)
                        {
                          xmax=x1;
                        }
                      for(int j=0;j<c.getChildNodes().getLength();j++)
                        {
                          Node d=c.getChildNodes().item(j);
                          if(d.getNodeType()==Node.ELEMENT_NODE&&d.getNodeName().equalsIgnoreCase("branch"))
                           {
                              drawGatewayBranch(g, x1, y1, y);
                              if(!d.hasChildNodes())
                              {
                              extra=x1;
                              }
                              else
                              {
                              LC(g, d, x1, y1);
                              }
                              if(ymax>y1+h/2)
                               {
                                 ymax=y1+h/2;
                               }
                               if(ymin>y1)
                                {
                                  ymin=y1;
                                }
                               Dimension.put(y1+h/2,extra);
                               y1=y1+h+h;
                           }
                        }
                       MergeGatewayBranches(g,c.getChildNodes().getLength(),c.getAttributes().getNamedItem("name").getNodeValue());
                        if(xmax<x1)
                         {
                           xmax=x1;
                         }
                        if(ymax<y1)
                         {
                           ymax=y1;
                         }
                         y1=y1-3*h;
                         if(ymin>y1)
                           {
                             ymin=y1;
                           }
                      if(x1<xmax)
                      {
                        x1=xmax+w/2;
                        //horizontal line after merge
                        g.drawLine(x1-w/2, y1+h/2, x1, y1+h/2);
                        g.drawLine(x1-10, y1+h/2-10, x1, y1+h/2);
                        g.drawLine(x1-10, y1+h/2+10,x1, y1+h/2);
                      }
                     else
                      {
                        x1=x1+w+w/2;
                      }
                 }
                else if(status.size()==0)
                  {
                    for(int j=0;j<c.getChildNodes().getLength();j++)
                     {
                       Node d=c.getChildNodes().item(j);
                       if(d.getNodeType()==Node.ELEMENT_NODE&&d.getNodeName().equalsIgnoreCase("branch"))
                         {
                           LC(g, d, x1, y1); 
                           if(ymin>y1)
                            {
                              ymin=y1;
                            }
                           if(ymax<y1)
                            {
                              ymax=y1;
                            }
                           if(xmax<x1)
                            {
                              xmax=x1;
                            }
                         }
                     }
                  }
                if(c.getNextSibling()!=null)
                 {
                   if(x1<xmax)
                    {
                      x1=xmax;
                     }
                 }
            }
          }
       }
   }
    
    public static void MergeGatewayBranches(Graphics g, int size,String name)
      {
        ArrayList<Integer> keys=new ArrayList();
        int index=Dimension.size()-1;
        int key=0;
        int value=0;
        int key1=0;
        int value1=0;
        int i=0;
       
        for(Entry<Integer, Integer> entry : Dimension.entrySet())
         {   
           key=entry.getKey();
           value=entry.getValue();
          }
        while(index>=0&&(i<size))
        {
          int firstKey = (int) Dimension.keySet().toArray()[index];
          keys.add(firstKey);
          if(key1==0)
           {
             key1=firstKey;
           }
        int valueForFirstKey = Dimension.get(firstKey);
        i=i+1;
        if(value1==0)
          {
            value1=valueForFirstKey;
          }
        if(valueForFirstKey<xmax)
            {
              g.drawLine(valueForFirstKey, firstKey, xmax, firstKey);
            }
       else if(valueForFirstKey>xmax)
          {
            g.drawLine(xmax, firstKey, valueForFirstKey, firstKey);
          }
     
       if(key1<firstKey)
        {
           g.drawLine(xmax, key1, xmax, firstKey);
        }
       else if(key1>firstKey)
        {
          g.drawLine(xmax, firstKey, xmax, key1);
        }
       else 
        {
          g.drawLine(valueForFirstKey,firstKey ,value1,key1);
        }
        index=index-1;
      }
        i=0;
        index=Dimension.size()-1;//2
        
        for(Integer in: keys)
          {
            if(index>0&&(i<=size))
              {
                Dimension.remove(in);
                index=index-1;
                i=i+1;
              }
          }
       }
     
    public static ArrayList<String> CheckStates(Graphics g, Node n)
      {
       for(int i=0;i<n.getChildNodes().getLength();i++)
         {
           Node p=n.getChildNodes().item(i);
           if(p.getNodeType()==Node.ELEMENT_NODE&&p.getNodeName().equalsIgnoreCase("branch"))
            {
             for(int j=0;j<p.getChildNodes().getLength();j++)
              {
                Node t=p.getChildNodes().item(j);
                if(t.getNodeType()==Node.ELEMENT_NODE)
                  {
                    if(t.getNodeName().equalsIgnoreCase("State"))
                      {
                        String state= t.getAttributes().getNamedItem("in").getNodeValue();
                        status.add(id);
                      }
                  }
              }
            }
         }
         return status;
      }
      
    public static int Construct(Graphics g,Node n, int x, int y)
      {
        state=n.getAttributes().getNamedItem("in").getNodeValue();
        if(!state.equalsIgnoreCase(PreviousState))
          {
            x=drawStateShape(g, n, state, x, y);
          }
        else 
          {
            if(n.getParentNode().getNodeName().equalsIgnoreCase("branch"))
             {
               Node prev=n.getPreviousSibling();
               if(prev!=null&&prev.getNodeType()!= Node.ELEMENT_NODE)
                 {
                   prev=prev.getPreviousSibling();
                 }
                if(prev==null)
                  {
                    x= drawStateShape(g, n, state, x, y);
                  }
                 else 
                  {
                   if(prev.getNodeName().equalsIgnoreCase("State"))
                    {
                     if(!prev.getAttributes().getNamedItem("in").getNodeValue().equalsIgnoreCase(state))
                      {
                        x= drawStateShape(g, n, state, x, y);
                      }
                    }
                   else if (prev.getNodeName().equalsIgnoreCase("gateway"))
                    {
                      x= drawStateShape(g, n,state, x, y);
                    }
              }
            }
          }
          return x;
      }
    
    public static int drawStateShape(Graphics g, Node n,String state, int x, int y)
     {
       GetStateDimension(g,SyncObj,Artifact,state,x,y,map);
       PreviousState=state;
        g.drawOval(x, y, w, h);
        SetString.setString(g, state, w,h, x, y);
        g.drawLine(x+w, y+h/2, x+w+w/2, y+h/2);
        x = x+w+w/2;
        if(n.getParentNode().getLastChild().getPreviousSibling()!=n)
         {
          g.drawLine(x-10, y+h/2-10, x, y+h/2);
          g.drawLine(x-10, y+h/2+10, x, y+h/2);
         }
        return x;
     }
   
   public static void drawGatewayShape(Graphics g, int x, int y)
     {
       g.drawLine(x, y+h/2, x+w/2, y);
       g.drawLine(x+w/2, y, x+w, y+h/2);
       g.drawLine(x, y+h/2, x+w/2, y+h);
       g.drawLine(x+w/2, y+h, x+w, y+h/2);
     }
   
   public static void drawGatewayBranch(Graphics g, int x1, int y1, int y)
     {
       if(y1<y)
        {
          g.drawLine(x1-w/4, y1+h/2, x1-w/4, y+h/2);
          g.drawLine(x1-w/4, y1+h/2, x1, y1+h/2);
        }
       else
        {
          g.drawLine(x1-w/4, y1+h/2, x1-w/4, y+h/2);
          g.drawLine(x1-w/4, y1+h/2, x1, y1+h/2);
        }
     }
   
   public static void SynchronizeALC(ArrayList<Map<List<String>, List<Integer>>> myList,NodeList SyncObj,Graphics g)
       {
        int count=5,x2=0,y2=0;
        Graphics2D g2d = (Graphics2D) g.create();   
        Stroke dashed = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{9}, 0);
        g2d.setStroke(dashed);
        for(int u=0;u<SyncObj.getLength();u++)
          {
            Node Obj=SyncObj.item(u);
            if(Obj.getNodeType()==Node.ELEMENT_NODE)
              {
                sourceobject=Obj.getAttributes().getNamedItem("SourceObj").getNodeValue();
                destinationobject=Obj.getAttributes().getNamedItem("DestinationObj").getNodeValue();
                source=Obj.getAttributes().getNamedItem("SourceState").getNodeValue();
                destination=Obj.getAttributes().getNamedItem("DestinationState").getNodeValue();
              }
              for(int i=0;i<myList.size();i++)
                {
                   Map<List<String>,List<Integer>> map=myList.get(i);
                   for(Map.Entry<List<String>, List<Integer>> entry : map.entrySet()) 
                     {
                        List<String> key = entry.getKey();
                        List<Integer> values = entry.getValue();
                        if(key.get(0).equalsIgnoreCase(sourceobject)&&key.get(1).equalsIgnoreCase(source))
                         {
                           x1=values.get(0);
                           y1=values.get(1);
                           map1.put(x1, y1);
                           
                         }
                        if(key.get(0).equalsIgnoreCase(destinationobject)&&key.get(1).equalsIgnoreCase(destination))
                         {
                           x2=values.get(0);
                           y2=values.get(1);
                           
                           map1.put(x2, y2);
                         }
                      }
                 }
                 if((x1!=0)&&y1!=0&&x2!=0&&y2!=0)
                   { 
                     if(u%2==0)
                       {
                         g2d.setColor(Color.red);
                       }
                     else 
                       {
                         g2d.setColor(Color.blue);  
                       }
                                       
                     if((map1.containsKey(x1)&&map1.containsValue(y1)&&map1.containsKey(x2)&&map1.containsValue(y2)))
                      {
                        while(map1.containsKey(x1))
                         {
                           x1=x1+count;
                         }
                        while(map1.containsKey(x2))
                         {
                           x2=x2+count;
                         }
                        while(map1.containsKey(y1))
                         {
                          y1=y1+count;
                         }
                        while(map1.containsKey(y1))
                         {
                           y2=y2+count;
                         }
                         count=count+5;
                      }
                      g2d.drawLine(x1-20, y1+25, x1-20,y1+60 );
                      g2d.drawLine(x2-20, y2, x2-20,y2+25 );
                      g2d.drawLine(x1-20, y1+60, x2-20, y1+60);
                      g2d.drawLine(x2-20, y2, x2-20, y1+60);
                   } 
           }
       }       
    
  public static void GetStateDimension(Graphics g2d,NodeList SyncObj, Node n,String state,int x,int y, Map<List<String>, List<Integer>> map)
    {
      List<Integer> valSetOne = new ArrayList<Integer>();     
      List<String> valSetTwo = new ArrayList<String>();     
      for(int u=0;u<SyncObj.getLength();u++)
       {
         Node Obj=SyncObj.item(u);
         if(Obj.getNodeType()==Node.ELEMENT_NODE)
           {
             if(Obj.getAttributes().getNamedItem("SourceObj").getNodeValue().equalsIgnoreCase(n.getNodeName())||Obj.getAttributes().getNamedItem("DestinationObj").getNodeValue().equalsIgnoreCase(n.getNodeName()))
              {
                if(state.equalsIgnoreCase(Obj.getAttributes().getNamedItem("SourceState").getNodeValue()))
                 {
                   valSetOne.add(x);
                   valSetOne.add(y);
                   valSetTwo.add(n.getNodeName());
                   valSetTwo.add(state);
                   map.put(valSetTwo, valSetOne);
                 }
                else if(state.equalsIgnoreCase(Obj.getAttributes().getNamedItem("DestinationState").getNodeValue()))
                 {
                   valSetOne.add(x);
                   valSetOne.add(y);
                   valSetTwo.add(n.getNodeName());
                   valSetTwo.add(state);
                   map.put(valSetTwo, valSetOne);
                 }
               }
            }
        }
    }
 }
   
   
  
   
           
       



  




