package ALCSynthesis.Visualization;

import ALCSynthesis.Visualization.VisualizeALC;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class CreatePNG extends JPanel
  {
    public static int maxWidth,totalHeight;
    public CreatePNG()
     {
       maxWidth    = 10000;
       totalHeight = 10000;
     }
    
    public void paintComponent(Graphics g)
     {  
       super.paintComponent(g);
       super.setBackground(Color.white);
       VisualizeALC.drawing(g);
       getImage(g);
    } 
    public static Image getImage(Graphics g)
    {
      BufferedImage bi = new BufferedImage(maxWidth, totalHeight, BufferedImage.TYPE_INT_RGB);
       Graphics2D ig2 = bi.createGraphics();
       ig2.setBackground(Color.yellow);
       ig2.setColor(Color.white);
        try {
            ImageIO.write(bi, "PNG", new File("C:\\Synthesis\\ALCImage.PNG"));// or ALCImage.JPG (both work)
        } catch (IOException ex) {
            Logger.getLogger(CreatePNG.class.getName()).log(Level.SEVERE, null, ex);
        }
        return bi;
    }
}       
    
            
        
        
     
        
        
       
        
       


    
    

