/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ALCSynthesis.Visualization;

import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author kjyothi
 */
public class SetString {
    
    public static void setString(Graphics g,String s,int w,int h, int x,int y)
       {
          FontMetrics fm=g.getFontMetrics();
          int sw=fm.stringWidth(s);
          if(sw<w)
            {
               g.drawString(s, x+w/2-sw/2, y+h/2);
            }
          else if(sw>w||sw==w)
            {
               int yt=y;
               if(s.contains(" "))
                 {
                   String[] parts=s.split(" ");
                   for(int m=0;m<parts.length;m++)
                     {
                       String part1=parts[m];
                       int sw1=fm.stringWidth(part1);
                       if(sw1<=w)
                         {
                           g.drawString(part1, x+w/2-sw1/2, yt+h/3);
                           yt=yt+h/4;
                         }
                       else
                         {
                           yt=StringBuild(g,part1,fm, x,yt-h/6,w,h);  
                         }
                      }
                  }
               else
               {
                   g.drawString(s, x+5, yt+h/2);
               }
            }
      }
    
    public static int StringBuild(Graphics g,String part1,FontMetrics fm,int x,int yt,int w,int h)
      {
        int sb1=0;
        ArrayList<String> sub=new ArrayList<String>();
        StringBuilder sb=new StringBuilder();
        for(int n=0;n<part1.length();n++)
          {
            char ch=part1.charAt(n);
            sb.append(ch);
            sb1=fm.stringWidth(sb.toString());
            if(sb1>=w-10)
              {
                sub.add(sb.toString());
                sb=new StringBuilder();
              }
            if(n==part1.length()-1)
              {
                sub.add(sb.toString());
              }
          }
          for(int j=0;j<sub.size();j++)
            {
               sb1=fm.stringWidth(sub.get(j));
               if(j<sub.size()-1)
                 {
                    String str=sub.get(j);
                    str=str+'-';
                    g.drawString(str, x+w/2-sb1/2, yt+h/2);
                    yt=yt+h/4;
                 }
               else
                 {
                   g.drawString(sub.get(j), x+w/2-sb1/2, yt+h/2);
                   yt=yt+h/4;
                 }
            }
            return yt;
       }
    
}
