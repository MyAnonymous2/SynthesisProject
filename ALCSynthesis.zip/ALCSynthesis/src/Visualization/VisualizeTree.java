/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ALCSynthesis.Visualization;

import Synthesis.BuildProcessTree;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import javax.swing.JPanel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kjyothi
 */
public class VisualizeTree extends JPanel
  {
    public static int nlength,w=80,h=80,x2,y2,xmax=0;  //w=width, h=height
    public static String s;
    public static int maxWidth;
    public static int totalHeight;
    public static NodeList ArtifactList;
    public VisualizeTree() 
      {
        maxWidth    = 10000;
        totalHeight = 10000;
      }
    public Dimension getPreferredSize() 
      {
        return new Dimension(maxWidth, totalHeight);
      }
    
    public static void VisualizeTree (Graphics g,int x, int y)
      {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setFont(new Font("TimesRoman", Font.BOLD, 14)); 
        BasicStroke bs1 = new BasicStroke(2, BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL);
        g2d.setStroke(bs1);
        try                                                           
          {
           BuildProcessTree ProcessTree=new BuildProcessTree();
           File fXmlFile =ProcessTree.GetFile();
           DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
           DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
           Document doc = dBuilder.parse(fXmlFile);
           ArtifactList=doc.getDocumentElement().getElementsByTagName("object");
           NodeList nList=doc.getElementsByTagName("ProcessTree");
           int z=10;
           Node Seq=nList.item(0).getFirstChild();
           if(Seq!=null&&Seq.getNodeType()!=Node.ELEMENT_NODE)
            {
              Seq=Seq.getNextSibling();
            }
            if(Seq.getNodeType()==Node.ELEMENT_NODE&&Seq.getNodeName().equalsIgnoreCase("SEQ")&&Seq.hasChildNodes())
              {
                s=Seq.getNodeName();
                g.drawRoundRect(x/2+3*w,z,w,h,20, 20); 
                g.setColor(Color.GREEN);
                g.fillRoundRect(x/2+3*w,z, w, h, 20, 20);  
                g.setColor(Color.black);
                SetString.setString(g,s,w,h,x/2+3*w,z);
                g.drawLine(x/2+3*w+w/2, z+h, x/2+3*w+w/2, z+h+h/4); 
                NodeList SList=Seq.getChildNodes();
                nlength=SList.getLength();  
                x=x/2-w/2;
                int x1=getX(g,nlength,x,z,w,h);
                int y1=z+h+h/2;
                g2d.setFont(new Font("TimesRoman", Font.BOLD, 12)); 
                DrawShapes(g,SList,x1,y1,w,h,x+w/2);
              }
          }
        catch(Exception e) 
          {
            e.printStackTrace();
          }
    }
      
    public static void DrawShapes(Graphics g, NodeList nList,int x, int y, int w,int h,int d)
      {
        for(int j=0;j<nList.getLength();j++)
          {
            Node sc=nList.item(j);
            if(sc.getNodeType()==Node.ELEMENT_NODE)
              {
                if(!sc.getNodeName().equalsIgnoreCase("Seq"))
                  {
                    if(sc.hasAttributes())
                     {
                       if(!sc.getNodeName().equalsIgnoreCase("inputobject")&&!sc.getParentNode().getNodeName().equalsIgnoreCase("outputobject")&&!sc.getParentNode().getNodeName().equalsIgnoreCase("inputobject")&&!sc.getNodeName().equalsIgnoreCase("outputobject"))
                         {
                           s=sc.getAttributes().getNamedItem("name").getNodeValue();
                         }
                       else if(sc.getNodeName().equalsIgnoreCase("inputobject")||sc.getNodeName().equalsIgnoreCase("outputobject"))
                         {
                           s=sc.getNodeName();
                         }
                         if(sc.getParentNode().getNodeName().equalsIgnoreCase("outputobject")||sc.getParentNode().getNodeName().equalsIgnoreCase("inputobject"))
                           {
                             s=sc.getAttributes().getNamedItem("state").getNodeValue();
                             String id=sc.getAttributes().getNamedItem("id").getNodeValue();
                             s=getObject(s,id);
                           }
                      }
                    else
                      {
                        s=sc.getNodeName();
                      }
                    }
                  else
                    {
                      s=sc.getNodeName();
                    }
                    if(sc.getNodeName().equalsIgnoreCase("startEvent")&&s.equalsIgnoreCase("init"))
                      {
                        g.drawOval(x, y, 80,80);
                        SetString.setString(g,s,w,h,x,y);
                        g.drawLine(x+w/2, y-h/4, d, y-h/4);
                        g.drawLine(x+w/2, y-h/4, x+w/2, y);
                        x=x+w+w/4;
                        xmax=x;
                      }
                    else if(s.equalsIgnoreCase("End"))
                      {
                        Graphics2D gd=(Graphics2D) g;
                        BasicStroke bs2 = new BasicStroke(4, BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL);
                        gd.setStroke(bs2);
                        g.drawOval(x, y, 80,80);
                        BasicStroke bs3 = new BasicStroke(2, BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL);
                        gd.setStroke(bs3);
                        SetString.setString(g,s,w,h,x,y);
                        g.drawLine(x+w/2, y-h/4, d, y-h/4);
                        g.drawLine(x+w/2, y-h/4, x+w/2, y);
                      }
                    else
                      {
                        if(sc.getNodeName().equalsIgnoreCase("gateway"))
                          {
                           s=sc.getAttributes().getNamedItem("name").getNodeValue();
                           drawGatewayShape(g,x+2*w,y);
                           SetString.setString(g,s,w,h,x+2*w,y);
                           g.drawLine(x+2*w+w/2, y-h/4, x+2*w+w/2, y);
                           g.drawLine(x+2*w+w/2, y+h, x+2*w+w/2, y+h+h/4);
                           g.drawLine(x+2*w+w/2, y-h/4, d, y-h/4);
                          }
                        else
                          {
                            g.drawRoundRect(x,y,h,w,20, 20);
                            if(sc.getNodeName().equalsIgnoreCase("task"))
                             {
                              g.setColor(Color.cyan);
                              g.fillRoundRect(x, y, h, w, 20, 20);
                              g.setColor(Color.black);
                             }
                            else if(sc.getNodeName().equalsIgnoreCase("seq"))
                             {
                              g.setColor(Color.green);
                              g.fillRoundRect(x, y, h, w, 20, 20);
                              g.setColor(Color.black);
                             }
                            else if(sc.getParentNode().getNodeName().equalsIgnoreCase("inputobject")||sc.getParentNode().getNodeName().equalsIgnoreCase("outputobject"))
                             {
                              g.setColor(Color.pink);
                              g.fillRoundRect(x, y, h, w, 20, 20);
                              g.setColor(Color.black);
                             }
                            else if(!sc.getNodeName().equalsIgnoreCase("inputobject")&&!sc.getNodeName().equalsIgnoreCase("outputobject"))
                             {
                              g.setColor(Color.orange);
                              g.fillRoundRect(x, y, h, w, 20, 20);
                              g.setColor(Color.black);
                             }
                           }
                           if(!sc.getNodeName().equalsIgnoreCase("gateway"))
                             {
                               SetString.setString(g,s,w,h,x,y);
                             }
                             g.drawLine(x+w/2, y-h/4, d, y-h/4);
                             if(!sc.getNodeName().equalsIgnoreCase("gateway"))
                              {
                                g.drawLine(x+w/2, y-h/4, x+w/2, y);
                              }
                              if(sc.hasChildNodes())
                               {
                                if(!sc.getNodeName().equalsIgnoreCase("gateway"))
                                 {
                                   g.drawLine(x+w/2, y+h, x+w/2, y+h+h/4);
                                 }
                                 NodeList gList=sc.getChildNodes();
                                 x2=x;
                                 if(!sc.getNodeName().equalsIgnoreCase("gateway")&&!sc.getNodeName().equalsIgnoreCase("seq"))
                                  {
                                   if(sc.getChildNodes().getLength()>1)
                                     {
                                       x2=x2-w/4;
                                     }
                                  }
                                  y2=y+h+h/2;
                                  DrawShapes(g,gList,x2,y2,w,h,x2+w/2);
                                }
                              else
                                {
                                 if(sc.getNodeName().equalsIgnoreCase("inputobject")||sc.getNodeName().equalsIgnoreCase("outputobject"))
                                   {
                                     int y1=y+h+h/2;
                                     s=sc.getAttributes().getNamedItem("state").getNodeValue();
                                     String id=sc.getAttributes().getNamedItem("id").getNodeValue();
                                     s=getObject(s,id);
                                     g.drawRoundRect(x,y1,h,w,20, 20);
                                     g.setColor(Color.pink);
                                     g.fillRoundRect(x, y1, h, w, 20, 20);
                                     g.setColor(Color.black);
                                     SetString.setString(g,s,w,h,x,y1);
                                     g.drawLine(x+w/2, y1-h/2, x+w/2, y1);
                                   }
                                   x=x+w+w/2;
                                   if(xmax<x)
                                    {
                                      xmax=x;
                                    }
                                }
                                if(x<xmax)
                                 {
                                   x=xmax;
                                 }
                                else
                                 {
                                   xmax=x;   
                                 }         
                      }
              }
           }
      }
    
    public static void drawGatewayShape(Graphics g,int x,int y)
      {
        g.setColor(Color.ORANGE);
        Graphics2D gd=(Graphics2D) g;
        BasicStroke bs2 = new BasicStroke(4, BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL);
        gd.setStroke(bs2);
        g.drawLine(x, y+h/2, x+w/2, y);
        g.drawLine(x+w/2,y,x+w,y+h/2);
        g.drawLine(x, y+h/2, x+w/2, y+h);
        g.drawLine(x+w/2,y+h,x+w,y+h/2);
        BasicStroke bs3 = new BasicStroke(2, BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL);
        gd.setStroke(bs3);
        g.setColor(Color.black);
      }
    
    public static String getObject(String s, String id)
      {
        for(int i=0;i<ArtifactList.getLength();i++)
         {
           String object=ArtifactList.item(i).getAttributes().getNamedItem("id").getNodeValue();
           if(object.equalsIgnoreCase(id))
            {
              s=ArtifactList.item(i).getAttributes().getNamedItem("name").getNodeValue()+":"+" ["+s+"]";
            }
         } 
         return s;
      }
 
    public static int getX(Graphics g,int nlength,int x,int z,int w,int h)
      {
       if(nlength%2==0)
         {
           x=x-(((nlength-1)*w)+(nlength-1*w/4));
           z=z+h+h/2; 
         }
       else
         {
           x=x-(nlength/2*(w+w/2));
           z=z+h+h/2;
         }
         return x;
      } 
    
    public void paintComponent(Graphics g)
      {
        super.paintComponent(g);
        super.setBackground(Color.yellow);
        int x=super.getWidth();
        int y=super.getHeight();
        VisualizeTree(g,x,y);
      }
   }
       
    
            
        
        
     
        
        
       
        
       


    
    



