/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Synthesis;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Attr;
import org.w3c.dom.NamedNodeMap;
/**
 *0.
 * @author kjyothi
 */
public class BuildXMLFile 
   {
  public static Element CreateDocumentElement(Document BPMN,Document document,String rootElement,String Elementchild)
     {
        Element DocElement = document.createElement(rootElement);
        document.appendChild(DocElement);
        Element objects = document.createElement("Objects");
        DocElement.appendChild(objects);
        NodeList ArtifactList=BPMN.getDocumentElement().getElementsByTagName("object");
        BuildXMLFile.addArtifactSet(ArtifactList, objects, document);
        Element Child = document.createElement(Elementchild);
        DocElement.appendChild(Child);
        return Child;
     }
      
   public static void addArtifactSet(NodeList ArtifactList, Element objects,Document document)
     {
       for(int i=0;i<ArtifactList.getLength();i++)
        {
          Node n=ArtifactList.item(i);
          if(n.getNodeType()==Node.ELEMENT_NODE)
            {
              Element obj=document.createElement(n.getNodeName());
              objects.appendChild(obj);
              addAttributes(obj,n,document);
            }
        }
     }
   
   public static void createElement(Node n,Element e,Document document)
     {
       if(n.hasAttributes())
         {
           addAttributes(e, n, document);
         }
         if(!n.getNodeName().equalsIgnoreCase("gateway")&&n.hasChildNodes())
           {
             NodeList sub=n.getChildNodes();
             for(int i=0;i<sub.getLength();i++)
               {
                 Node sn=sub.item(i);
                 if(sn.getNodeType()==Node.ELEMENT_NODE&&(!sn.getNodeName().equalsIgnoreCase("xorjoin")&&!sn.getNodeName().equalsIgnoreCase("andmerge")))
                   {
                     Element ch=document.createElement(sn.getNodeName());
                     e.appendChild(ch);
                     createElement(sn,ch,document);
                   }
               }
           }
         if(n.getNodeName().equalsIgnoreCase("gateway")&&n.hasChildNodes())
           {
             NodeList sub1=n.getChildNodes();
             for(int i=0;i<sub1.getLength();i++)
               {
                 Node sn1=sub1.item(i);
                 if(sn1.getNodeName().equalsIgnoreCase("inputobject")||sn1.getNodeName().equalsIgnoreCase("outputobject"))
                  {
                    Element ch2=document.createElement(sn1.getNodeName());
                    e.appendChild(ch2);
                    createElement(sn1,ch2,document);
                  }
               }
            }
      }
   
    public static void addAttributes(Element ch1,Node n,Document document)
      {
        if(n.hasAttributes())
          {
            NamedNodeMap AtList=n.getAttributes();
            for (int j=0;j<AtList.getLength();j++)
              {
                Attr a=(Attr) AtList.item(j);
                Attr a1=document.createAttribute(a.getName());
                a1.setNodeValue(a.getValue());
                ch1.setAttributeNode(a1);
              }
          }
      }
}
