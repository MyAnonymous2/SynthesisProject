package ALCSynthesis.Visualization;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import org.apache.batik.swing.JSVGCanvas;

public class VisualizeSVG 
  {
    public JSVGCanvas svgCanvas = new JSVGCanvas();
    public static int maxWidth;
    public static int maxHeight;
    public VisualizeSVG()
      {
        maxWidth  = 6000;
        maxHeight = 6000;
      }
    public JComponent createComponents()
      {
        final JPanel panel = new JPanel(new BorderLayout());
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.add("North", p);
        panel.add("Center", svgCanvas);
        JFileChooser fc = new JFileChooser(".");
        fc.setCurrentDirectory(new File("C:\\Synthesis\\Desktop"));
        int choice = fc.showOpenDialog(panel);
        if (choice == JFileChooser.APPROVE_OPTION) 
          {
            File f = fc.getSelectedFile();
            try 
             {
               svgCanvas.setURI(f.toURL().toString());
             } 
            catch (IOException ex) 
             {
                ex.printStackTrace();
             }
          }
           return panel;
      }
  }
