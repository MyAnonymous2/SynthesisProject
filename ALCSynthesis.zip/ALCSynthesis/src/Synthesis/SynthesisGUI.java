package Synthesis;

import ALCSynthesis.Visualization.CreatePNG;
import ALCSynthesis.Visualization.ProcessElementCount;
import ALCSynthesis.Visualization.VisualizeALC;
import ALCSynthesis.Visualization.VisualizeSVG;
import ALCSynthesis.Visualization.VisualizeTree;
import Synthesis.BuildProcessTree;
import Synthesis.GenerateALCs;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import org.w3c.dom.NodeList;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.plaf.basic.BasicMenuBarUI;

public class SynthesisGUI extends JFrame
  {

    public JSplitPane splitPaneV, splitPaneH, splitPaneH1;
    public static JPanel panel1, panel2, panel3, panel4;
    public JButton button1= new JButton( "BPMN Process Model" );
    public JButton button2= new JButton( "Tree Model" );
    public JButton button4=  new JButton( "Synchronized Artifact LifeCycle" );
    public static JScrollPane scrollPane;
    public static JTree NodeCounts,ProcessStructure;
    public static DefaultMutableTreeNode root = new DefaultMutableTreeNode("Element Count");
    public static DefaultMutableTreeNode rootNode=new DefaultMutableTreeNode("Process");
    public static File selectedFile,ProcessTree,ALCs;
    public static NodeList ArtifactList,ActivityCount,GatewayCount,StateCount,SequenceCount,NextSetCount;

    public void AddPanelsToTextArea()
      {
        super.setBackground( Color.gray );
        super.setJMenuBar(addMenu());
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        super.add(topPanel);
       
        // Create the panels
        createPanels();

        // Create a splitter pane
        splitPaneV = new JSplitPane( JSplitPane.VERTICAL_SPLIT );
        topPanel.add( splitPaneV, BorderLayout.CENTER );
        splitPaneH = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT );
        splitPaneH.setLeftComponent( panel1 );
        splitPaneV.setLeftComponent( splitPaneH );
        splitPaneH1 = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT );
        splitPaneH1.setLeftComponent( panel2 );
        splitPaneH1.setRightComponent(new JSplitPane( JSplitPane.VERTICAL_SPLIT, panel3, panel4));
        splitPaneV.setRightComponent( splitPaneH1 );
      }
        
    public static JMenuBar addMenu()
      {
        JMenuBar menuBar=new JMenuBar();
        menuBar.setUI ( new BasicMenuBarUI (){
        public void paint ( Graphics g, JComponent c ){
        g.setColor (Color.cyan);
        g.fillRect ( 0, 0, c.getWidth (), c.getHeight () );
            }
        } );
        JMenu fileMenu=new JMenu("File");
        JMenu ViewMenu=new JMenu("View");
        JMenu closeMenu=new JMenu("Close");
        JMenu OpenMenuItem= new JMenu("Open");
        JMenu SaveMenuItem= new JMenu("Save");
        JMenuItem SVGMenuItem=new JMenuItem("SVG");
        JMenuItem XMLMenuItem= new JMenuItem("XML");
        JMenuItem PNGImage= new JMenuItem("As PNG");
        JMenuItem ExitMenuItem=new JMenuItem("Exit");
        JMenuItem TreeViewMenuItem=new JMenuItem("Tree");
        JMenuItem ALCViewMenuItem= new JMenuItem("ALC");
        JMenuItem exitMenuItem=new JMenuItem("Exit");
      
        SVGMenuItem.addActionListener(new ActionListener()
          {
            @Override
            public void actionPerformed(ActionEvent event) 
             {
                VisualizeSVG svg=new VisualizeSVG();
                panel3.removeAll();
                scrollPane=new JScrollPane(svg.createComponents());
                panel3.add(scrollPane);
                panel3.setVisible(true);
                panel3.revalidate();
                panel3.repaint();
             }  
          });
        XMLMenuItem.addActionListener(new ActionListener()
          {
            @Override
            public void actionPerformed(ActionEvent event) 
             {
                selectedFile=GetFile();
                CountNodesandDisplay(selectedFile); 
                panel3.removeAll();
                panel3.setVisible(true);
                panel3.revalidate();
                panel3.repaint();
             }  
          });
         PNGImage.addActionListener(new ActionListener()
          {
            @Override
            public void actionPerformed(ActionEvent event) 
             {
                 BufferedImage bi = new BufferedImage(10000, 2000, BufferedImage.TYPE_INT_RGB);
                 Graphics2D ig2 = bi.createGraphics();
                 VisualizeALC.drawing(ig2);
                 try {
                    ImageIO.write(bi, "PNG", new File("C:\\Synthesis\\ALCImage.PNG"));// or ALCImage.JPG (both work)
                 } catch (IOException ex) {
                    Logger.getLogger(CreatePNG.class.getName()).log(Level.SEVERE, null, ex);
                }
                panel3.removeAll();
                ImageIcon icon = new ImageIcon(bi); 
                JLabel label = new JLabel(); 
                label.setIcon(icon); 
                scrollPane=new JScrollPane(label);
                panel3.add(scrollPane);
                panel3.setVisible(true);
                panel3.revalidate();
                panel3.repaint();
             }  
          });
         TreeViewMenuItem.addActionListener(new ActionListener()
          {
            @Override
            public void actionPerformed(ActionEvent e)
            {
              if(selectedFile!=null)
                {
                  BuildProcessTree PT=new BuildProcessTree();
                  ProcessTree=PT.Return(selectedFile);
                  CountNodesandDisplay(ProcessTree);
                  panel3.removeAll();
                  scrollPane=new JScrollPane(new VisualizeTree());
                  panel3.add(scrollPane);
                  if(true)
                    {
                      JOptionPane.showMessageDialog(null, "Please scroll right to view the tree");
                    }
                  panel3.setVisible(true);
                  panel3.revalidate();
                  panel3.repaint();

                }
              else
                {
                  JOptionPane.showMessageDialog(null, "Please browse/open an input file from File menu");
                }
            } 
          });
         ALCViewMenuItem.addActionListener(new ActionListener()
          {
            @Override
           public void actionPerformed(ActionEvent e)
             {
                if(selectedFile==null)
                  {
                    JOptionPane.showMessageDialog(null, "Please browse/open an input file from File menu");
                  }
                else
                 {
                    GenerateALCs ALC=new GenerateALCs();
                    ALCs=ALC.Construct(selectedFile, ProcessTree);
                    RefineSynchronize fil=new RefineSynchronize();
                    fil.Filter(ALCs);
                    panel3.removeAll();
                    scrollPane=new JScrollPane(new VisualizeALC());
                    panel3.add(scrollPane);
                    panel3.setVisible(true);
                    panel3.revalidate();
                    panel3.repaint();
                 }
             } 
          });
         OpenMenuItem.add(SVGMenuItem);
         OpenMenuItem.add(XMLMenuItem);
         SaveMenuItem.add(PNGImage);
         ViewMenu.add(TreeViewMenuItem);
         ViewMenu.add(ALCViewMenuItem);
         fileMenu.add(OpenMenuItem);
         fileMenu.add(SaveMenuItem);
         
         ExitMenuItem.addActionListener(new ActionListener()
           {
            @Override
            public void actionPerformed(ActionEvent event) 
             {
                System.exit(0);
             }
          });
          fileMenu.add(ExitMenuItem);
          exitMenuItem.addActionListener(new ActionListener()
           {
            @Override
            public void actionPerformed(ActionEvent event) 
             {
                System.exit(0);
             }
          });
          closeMenu.add(exitMenuItem);
          menuBar.add(fileMenu);
          menuBar.add(ViewMenu);
          menuBar.add(closeMenu);
          return menuBar;
      }

    public void createPanels()
      {
        //create Panel1
        panel1 = new JPanel();
        panel1.setBackground(Color.red);
        panel1.setLayout( new BorderLayout() );
        button1.setBackground(Color.pink);
        button2.setBackground(Color.pink);
        button4.setBackground(Color.pink);
        panel1.add( button1, BorderLayout.WEST );
        panel1.add( button2, BorderLayout.CENTER );
        panel1.add( button4, BorderLayout.EAST);

        //create Panel2
        panel2 = new JPanel();
        panel2.setLayout( new BorderLayout() );
        panel2.setBackground(Color.white);
        panel2.add(new TextArea(70,20),BorderLayout.NORTH);
        panel2.add(new TextArea(70,20),BorderLayout.SOUTH);

        //create Panel3
        panel3 = new JPanel();
        panel3.setLayout( new BorderLayout());
        panel3.setBackground(Color.white);
        panel3.add(new TextArea(40,10),BorderLayout.NORTH);
             
        //create Panel4
        panel4=new JPanel();
        panel4.setLayout(new BorderLayout());
        panel4.setBackground(Color.white);

        //Add actionlisterners to buttons
        button1.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent e)
            {
                selectedFile=GetFile();
                CountNodesandDisplay(selectedFile);
                panel3.removeAll();
                panel3.setVisible(true);
                panel3.revalidate();
                panel3.repaint();

            }
         });
        button2.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent e)
            {
              if(selectedFile!=null)
                {
                  BuildProcessTree PT=new BuildProcessTree();
                  ProcessTree=PT.Return(selectedFile);
                  CountNodesandDisplay(ProcessTree);
                  panel3.removeAll();
                  scrollPane=new JScrollPane(new VisualizeTree());
                  panel3.add(scrollPane);
                  if(true)
                    {
                      JOptionPane.showMessageDialog(null, "Please scroll right to view the tree");
                    }
                  panel3.setVisible(true);
                  panel3.revalidate();
                  panel3.repaint();

                }
              else
                {
                  JOptionPane.showMessageDialog(null, "Please browse/open an input file from File menu");
                }
            }
         });
       
        button4.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent e)
             {
                if(selectedFile==null)
                  {
                    JOptionPane.showMessageDialog(null, "Please browse/open an input file from File menu");
                  }
                else
                 {
                    GenerateALCs ALC=new GenerateALCs();
                    ALCs=ALC.Construct(selectedFile, ProcessTree);
                    RefineSynchronize fil=new RefineSynchronize();
                    fil.Filter(ALCs);
                    panel3.removeAll();
                    scrollPane=new JScrollPane(new VisualizeALC());
                    panel3.add(scrollPane);
                    panel3.setVisible(true);
                    panel3.revalidate();
                    panel3.repaint();
                 }
             }
         });
      }
    
        
    public static File GetFile()
      {
        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.setCurrentDirectory(new File("C:\\Users\\kjyothi\\Desktop"));
        int result = jFileChooser.showOpenDialog(new JFrame());
        if (result == JFileChooser.APPROVE_OPTION) 
          {
            selectedFile = jFileChooser.getSelectedFile();
          }
          return selectedFile;
      }
        
    public static void CountNodesandDisplay(File selectedFile)
      {
        NodeCounts= new JTree(ProcessElementCount.CountProcessNodes(root,selectedFile));
        final Font currentFont = NodeCounts.getFont();
        final Font bigFont = new Font(currentFont.getName(), currentFont.getStyle(), currentFont.getSize() + 5);
        NodeCounts.setFont(bigFont);
        panel4.removeAll();
        scrollPane=new JScrollPane(NodeCounts);
        panel4.add(scrollPane);
        panel4.setVisible(true);
        panel4.revalidate();
        panel4.repaint();
        ProcessStructure = new JTree(ProcessElementCount.ProcessNodeswithArtifacts(rootNode, selectedFile));
        final Font currentFont1 = ProcessStructure.getFont();
        final Font bigFont1 = new Font(currentFont1.getName(), currentFont1.getStyle(), currentFont1.getSize() + 5);
        ProcessStructure.setFont(bigFont1);
        JScrollPane sp = new JScrollPane(ProcessStructure);
        sp.setPreferredSize(panel2.getSize());
        panel2.removeAll();
        panel2.add(BorderLayout.NORTH, sp);;
        panel2.setVisible(true);
        panel2.revalidate();
        panel2.repaint();
      }
        
    public static void main( String args[] )
     {
        SynthesisGUI mainFrame = new SynthesisGUI();
        mainFrame.AddPanelsToTextArea();
        mainFrame.setTitle("Synthesis Tool");
        mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        mainFrame.setVisible(true);
      }
  }
