package Synthesis;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.NamedNodeMap;

public class RefineSynchronize
  {
    public static int count=0,newcount=0;
    public static Document document;
    public static Element Root, SyncElement=null;
    public static NodeList TreeNodes=null;
    public static NodeList LifecycleList, ArtifactList, ChildList, TaskList;
    public static Node Child=null;
    public static double TimeTotal;
    public static String xmlFilePath = "C:\\Synthesis\\ALCs\\MotivatingExampleRefSyncALCs.xml";
    public static File f;
    
    public static void Filter(File InputALC)  
     {  
     try 
       {
        File TreeModel= new File("C:\\Synthesis\\ProcessTrees\\MotivatingExampleProcessTree.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(InputALC);
        Document tree = dBuilder.parse(TreeModel);
        document = dBuilder.newDocument();
        LifecycleList=doc.getElementsByTagName("ArtifactLifeCycles");
        ArtifactList= tree.getDocumentElement().getElementsByTagName("object");
        TaskList= tree.getDocumentElement().getElementsByTagName("task");
        Root=document.createElement("ArtifactLifeCycles");
        document.appendChild(Root);
        
        Node ALC=LifecycleList.item(0);
        if(ALC!=null&&ALC.getNodeType()!=Node.ELEMENT_NODE)
         {
           ALC=ALC.getNextSibling();
         }
        for(int i=0;i<ALC.getChildNodes().getLength();i++)
          {
           if(ALC.getChildNodes().item(i).getNodeType()==Node.ELEMENT_NODE)
             {
               Child=ALC.getChildNodes().item(i);
               Element artifact=document.createElement(Child.getNodeName());
               Root.appendChild(artifact);
               count=0;
               newcount=0;
               count=RemoveEmptyGatewayNodes(Child.getChildNodes(),artifact,count);
             }
         }
        SyncElement=SynchronizeALCs(SyncElement);
        Root.appendChild(SynchronizeALCs(SyncElement));
                 
         // Create an instance of the test application
         TransformerFactory transformerFactory = TransformerFactory.newInstance();
         Transformer transformer = transformerFactory.newTransformer();
         DOMSource domSource = new DOMSource(document);
         StreamResult streamResult = new StreamResult(new File(xmlFilePath));
         transformer.transform(domSource, streamResult);
         System.out.println();
         System.out.println("Done creating XML File");
         f= new File(xmlFilePath);
       }          
     catch(Exception e) 
      {
        e.printStackTrace();
      }
      ReturnFile();
     }
     
   public static File ReturnFile()
     {
        return f;
     }
    
   public static int RemoveEmptyGatewayNodes(NodeList ChildList,Element artifact,int count)
     {
       for(int i=0;i<ChildList.getLength();i++)
        {
          if(ChildList.item(i).getNodeName().equalsIgnoreCase("State"))
           {
             String instate=ChildList.item(i).getAttributes().getNamedItem("in").getNodeValue();
             Node next=ChildList.item(i).getNextSibling();
             RemoveDuplicateStates(instate,next,artifact);
             if(ChildList.item(i).getParentNode().getNodeName().equalsIgnoreCase("branch"))
               {
                 count=count+1;
               }
            }
          else if (ChildList.item(i).getNodeName().equalsIgnoreCase("gateway"))
           {
            int c=0; 
            int p=0;
            newcount=newcount+1;
            Element gateway=document.createElement(ChildList.item(i).getNodeName());
            gateway.setAttribute("name", ChildList.item(i).getAttributes().getNamedItem("name").getNodeValue());
            for(int k=0;k<ChildList.item(i).getChildNodes().getLength();k++)
             {
              if(ChildList.item(i).getChildNodes().item(k).getNodeType()==Node.ELEMENT_NODE)
               {
                 Node branch=ChildList.item(i).getChildNodes().item(k);
                 Element br=document.createElement(branch.getNodeName());
                 if(branch.hasChildNodes())
                  {
                    c=0;
                    c=RemoveEmptyGatewayNodes(branch.getChildNodes(), br,c);
                    if(c>0)
                     {
                       count=c;
                     }
                  }
                 else
                  {
                     p=p+1;
                  }
                  gateway.appendChild(br);
               }
             }
             if(count>0)
              {
                int g=0;
                if(p<(ChildList.item(i).getChildNodes().getLength()))
                  {
                    for(int k=0;k<gateway.getChildNodes().getLength();k++)
                     {  
                       if(gateway.getChildNodes().item(k).getNodeType()==Node.ELEMENT_NODE&&!gateway.getChildNodes().item(k).hasChildNodes())
                         {
                           g=g+1;
                         }
                     }
                     if(g<(gateway.getChildNodes().getLength()))
                      {
                        artifact.appendChild(gateway);
                      }
                  }
              }
           }
        }
        return count;
     }
   
   public static void RemoveDuplicateStates(String instate,Node next, Node artifact)
     {
       if(next!=null&&next.getNodeType()!=Node.ELEMENT_NODE)
         {
           next=next.getNextSibling();
         }
         if(next!=null)
          {
            if(next.getNodeName().equalsIgnoreCase("State"))
              {
                if(!next.getAttributes().getNamedItem("in").getNodeValue().equalsIgnoreCase(instate))
                 {
                   Element State=document.createElement("State");
                   State.setAttribute("in",instate);
                   artifact.appendChild(State);
                 }
              }
            else 
              {
                Element State=document.createElement("State");
                State.setAttribute("in",instate);
                artifact.appendChild(State);
              }
            }
           else
            {
               Element State=document.createElement("State");
               State.setAttribute("in",instate);
               artifact.appendChild(State);
            }
       }
    public static Element SynchronizeALCs(Element SyncElement)
     {
      SyncElement=document.createElement("Synchronization");
      String obj1=null, obj2=null;
      for(int r=0;r<TaskList.getLength();r++)
        {
          Node n=TaskList.item(r);
          if(n.getNodeType()==Node.ELEMENT_NODE&&n.hasChildNodes())
            {
              for(int v=0;v<n.getChildNodes().getLength();v++)
               {
                 Node n2=n.getChildNodes().item(v);
                 if(n2.getNodeType()==Node.ELEMENT_NODE&&n2.getNodeName().equalsIgnoreCase("outputobject")&&n2.hasChildNodes())
                   {
                      NodeList nli=n2.getChildNodes();
                      for(int m=0;m<nli.getLength();m++)
                        {
                          Node nl=nli.item(m);
                          if(nl.getNodeType()==Node.ELEMENT_NODE)
                            {
                               Node nm=nl.getNextSibling();
                               if(nm!=null&&nm.getNodeType()!=Node.ELEMENT_NODE)
                                 {
                                   nm=nm.getNextSibling();
                                 }
                               if(nm!=null)
                                 {
                                   while(nm!=null&&nm.getNodeType()==Node.ELEMENT_NODE)    
                                     {
                                       if((!nl.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(nm.getAttributes().getNamedItem("id").getNodeValue())))
                                         {
                                           String ar1=nl.getAttributes().getNamedItem("state").getNodeValue();
                                           String ar2=nm.getAttributes().getNamedItem("state").getNodeValue();
                                           obj1=null;
                                           obj2=null;
                                           for(int i=0;i<ArtifactList.getLength();i++)
                                             {
                                               Node j=ArtifactList.item(i);
                                               if(j.getNodeType()==Node.ELEMENT_NODE)
                                                 {
                                                   String st=j.getAttributes().getNamedItem("id").getNodeValue();
                                                   if(obj1==null&&nl.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(st)&&nl.getAttributes().getNamedItem("state").getNodeValue().equalsIgnoreCase(ar1))
                                                     {
                                                       obj1 =j.getAttributes().getNamedItem("name").getNodeValue();
                                                     }
                                                   if (obj2==null&&nm.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(st)&&nm.getAttributes().getNamedItem("state").getNodeValue().equalsIgnoreCase(ar2))
                                                     {
                                                       obj2=j.getAttributes().getNamedItem("name").getNodeValue();
                                                     }
                                                 }
                                               /***** insert the following code and delete the if after for when you have more than 3 output objects with their states
                                             if((obj1!=null&&obj2!=null)&&(obj1!=obj2))
                                               {
                                                 System.out.println("Synchronize "+ obj1 + " and " + obj2 + " at states "+ ar1 +" and "+ ar2);
                                                 createSyncElt(rootElt,obj1, obj2, ar1, ar2);
                                                 obj1=null;
                                                 obj2=null;
                                               }
                                               * *****/
                                             }
                                             if((obj1!=null&&obj2!=null)&&(obj1!=obj2))
                                               {
                                                 System.out.println("Synchronize "+ obj1 + " and " + obj2 + " at states "+ ar1 +" and "+ ar2);
                                                 createSyncElt(SyncElement,obj1, obj2, ar1, ar2);
                                               }
                                         }
                                         nm=nm.getNextSibling();
                                         if(nm!=null&&nm.getNodeType()!=Node.ELEMENT_NODE)
                                          {
                                            nm=nm.getNextSibling();
                                          }
                                     }
                                 }
                             }
                         }
                     }
               }
            }
        }
      return SyncElement;
     }
     
   public static void createSyncElt(Element SyncElement,String object1, String object2, String state1, String state2)
     {
       Element SyncSet = document.createElement("SyncSet");
       if(object1.contains(""))
        {
          object1=object1.replaceAll("\\s+","");
          object1=object1.trim();
        }
       if (object2.contains(""))
        {
          object2=object2.replaceAll("\\s+","");
          object2=object2.trim();
        }
        SyncSet.setAttribute("SourceObj", object1);
        SyncSet.setAttribute("DestinationObj", object2);
        SyncSet.setAttribute("SourceState", state1);
        SyncSet.setAttribute("DestinationState", state2);
        SyncElement.appendChild(SyncSet);
     }
  }   
   
  
   
           
       



  




