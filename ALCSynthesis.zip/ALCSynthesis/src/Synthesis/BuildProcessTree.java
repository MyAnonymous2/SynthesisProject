package Synthesis;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

//class to build process tree and annotate artifacts
public class BuildProcessTree
  {
    public static File xmlFilePath =new File("C:\\Synthesis\\ProcessTrees\\MotivatingExampleProcessTree.xml");
    public static Document document;
    public static Element child = null;
    public static String DocElement="ProcessTreeXML",ElementChild="ProcessTree";
    
    public static File Return(File InputBPMN)  
      {
        try
         {
           DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
           DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
           Document BPMN = dBuilder.parse(InputBPMN);
           Element rootElement=BPMN.getDocumentElement();
           document = dBuilder.newDocument();
           Element ProcessTree=BuildXMLFile.CreateDocumentElement(BPMN,document,DocElement,ElementChild);
           if(rootElement.hasChildNodes())
             {
              for(int i=0;i<rootElement.getChildNodes().getLength();i++)
                {
                  Node process=rootElement.getChildNodes().item(i);
                  if(process.getNodeType()==Node.ELEMENT_NODE&&process.getNodeName().equalsIgnoreCase("processdef"))
                   {
                     Node StartEvent=process.getFirstChild().getNextSibling();
                     Element treeroot = document.createElement("SEQ");
                     ProcessTree.appendChild(treeroot);
                     BuildTree(StartEvent,treeroot,document);
                   }
                }
             }
            //transform the DOM Object to an XML File
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(xmlFilePath);
            transformer.transform(domSource, streamResult);
            System.out.println();
            System.out.println("Done creating XML File");
      }           
    catch(Exception e) 
       {
          e.printStackTrace();
       }
           
       return xmlFilePath;
   }
    
    //Recursive function to build process tree
    public static void BuildTree(Node n,Element root, Document d)
      {
        if(n!=null&&n.getNodeType()==Node.ELEMENT_NODE)
          {
            String nodename=n.getAttributes().getNamedItem("name").getNodeValue();
            if(!(nodename.equalsIgnoreCase("xorjoin")||(nodename.equalsIgnoreCase("andmerge"))))
              {
                child=document.createElement(n.getNodeName());
                BuildXMLFile.addAttributes(child, n, document);
                   
                if(n.getNodeName().equalsIgnoreCase("task"))
                  {
                    AnnotateArtifacts(n,child);
                  }
                  root.appendChild(child);
              }
            if(nodename.equalsIgnoreCase("xorsplit")||nodename.equalsIgnoreCase("andsplit"))
              {
                AppendGatewayNodes(n,child,d);
              }
              n=n.getNextSibling();
              if(n!=null&&n.getNodeType()!=Node.ELEMENT_NODE)
               {
                 n=n.getNextSibling();
               }
               BuildTree(n,root,d);
           }
      }
    
    public static void AppendGatewayNodes(Node n, Element child,Document d )
      {
        for(int t=0;t<n.getChildNodes().getLength();t++)
          {
            Node br=n.getChildNodes().item(t);
            if(br.getNodeType()==Node.ELEMENT_NODE&&br.getNodeName().equalsIgnoreCase("branch")&&br.hasChildNodes())    
              {
                Element subchild=document.createElement("SEQ");
                child.appendChild(subchild);
                Node SubCh=br.getFirstChild();
                if(SubCh!=null&&SubCh.getNodeType()!=Node.ELEMENT_NODE)
                  {
                    SubCh=SubCh.getNextSibling();
                  }
                  BuildTree(SubCh,subchild,d);
              }
          }
      }
    
    public static void AnnotateArtifacts(Node n,Element child)
      {
        for(int i=0;i<n.getChildNodes().getLength();i++)
         {
           Node subchild=n.getChildNodes().item(i);
           if(subchild.getNodeType()==Node.ELEMENT_NODE)
             {
               Element subch=document.createElement(subchild.getNodeName());
               if(subchild.hasAttributes())
                {
                  BuildXMLFile.addAttributes(subch, subchild, document);
                }
               else if(subchild.hasChildNodes())
                {
                  AnnotateArtifacts(subchild,subch);
                }
               child.appendChild(subch);
             }
         }
      }
     public static File GetFile()
          {
            return xmlFilePath;
          }
}


  




