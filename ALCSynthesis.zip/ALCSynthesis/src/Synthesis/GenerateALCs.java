package Synthesis;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class GenerateALCs
  {
    public static String status=null;
    public static Element E=null,gnode=null,State=null;
    public static Document document;
    public static NodeList TreeNodes=null;
    public static NodeList ArtifactList;
    public static Node Child= null;
    public static double TimeTotal;
    public static int count=0;
    public static String xmlFilePath = "C:\\Synthesis\\ALCs\\MotivatingExampleGeneratedALCs.xml";
    public static File f;
    
    public static File Construct(File xml, File InputBPMN)  
     {
      try 
       {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(InputBPMN);
        document = dBuilder.newDocument();
        E=document.createElement("ArtifactLifeCycles");
        document.appendChild(E);
        ArtifactList=doc.getDocumentElement().getElementsByTagName("object");
        for(int i=0;i<ArtifactList.getLength();i++)
         {
          if(ArtifactList.item(i).getNodeType()==Node.ELEMENT_NODE)
           {
             Node obj=ArtifactList.item(i);
             String name=obj.getAttributes().getNamedItem("name").getNodeValue();
             if(name.contains(""))
              {
                name= name.replaceAll("\\s+","");
              }
              Element ArtifactLifeCycle=document.createElement(name);
              ArtifactLifeCycle.setAttribute("id", obj.getAttributes().getNamedItem("id").getNodeValue());
              E.appendChild(ArtifactLifeCycle);
           }
        }
        TreeNodes=doc.getElementsByTagName("ProcessTree");
        Node treenode=TreeNodes.item(0);
        if(treenode.getNodeType()!=Node.ELEMENT_NODE)
          {
            treenode=treenode.getNextSibling();
          }
          if(treenode.hasChildNodes())
            {
              Node root=treenode.getFirstChild();
              if(root.getNodeType()!=Node.ELEMENT_NODE)
                {
                  root=root.getNextSibling();
                }
                if(root.getNodeType()==Node.ELEMENT_NODE)
                  {
                    Child= root.getFirstChild().getNextSibling();
                    if(Child.getNodeType()!=Node.ELEMENT_NODE)
                     {
                       Child=Child.getNextSibling();
                     }
                     Element ALC=E;
                     ConstructALC(Child, ALC);
                 }
            }
         // Create an instance of the test application
         TransformerFactory transformerFactory = TransformerFactory.newInstance();
         Transformer transformer = transformerFactory.newTransformer();
         DOMSource domSource = new DOMSource(document);
         StreamResult streamResult = new StreamResult(new File(xmlFilePath));
         transformer.transform(domSource, streamResult);
         System.out.println();
         System.out.println("Done creating XML File");
         f= new File(xmlFilePath);
      }          
    catch(Exception e) 
      {
        e.printStackTrace();
      }
      ReturnFile();
      return f;
    }
   public static File ReturnFile()
    {
        return f;
    }
    
   public static Element ConstructALC(Node Child, Element ALC)
     {
       if(Child!=null&&Child.getNodeType()!=Node.ELEMENT_NODE)
         {     
           Child=Child.getNextSibling();
         } 
       
         if(Child!=null&&Child.getNodeName().equalsIgnoreCase("task"))
           {
             for(int d=0;d<Child.getChildNodes().getLength();d++)
              {
                Node a=Child.getChildNodes().item(d);
                if(a.getNodeType()==Node.ELEMENT_NODE)
                 {
                   TestIO(a, ALC); 
                 }
              }  
           }
         else if(Child!=null&&Child.getNodeName().equalsIgnoreCase("gateway"))
           {
             AddNewGateway(Child,E,count);  
             count=count+1;
             for(int k=0;k<Child.getChildNodes().getLength();k++)
               {
                if(Child.getChildNodes().item(k).getNodeType()==Node.ELEMENT_NODE&&Child.getChildNodes().item(k).getNodeName().equalsIgnoreCase("SEQ"))
                 {
                   Element branch=null;
                   for(int p=0;p<E.getChildNodes().getLength();p++)
                     {
                      if(E.getChildNodes().item(p).getNodeType()==Node.ELEMENT_NODE)
                        {
                          branch= document.createElement("branch");
                          Node last=E.getChildNodes().item(p);
                          Node l=last;
                          int jp=0;
                          while(last.getLastChild()!=null)
                           {
                             if(last.getLastChild().getNodeName().equalsIgnoreCase("gateway"))
                               {
                                 jp=jp+1;
                                 if(jp==count)
                                  {
                                    l=last.getLastChild();
                                  }
                               }
                               last=last.getLastChild();
                           }
                           l.appendChild(branch);
                        }
                     }
                     ConstructALC(Child.getChildNodes().item(k).getFirstChild(), branch);
                 }
              }
              count=count-1;
            }
           else if(Child!=null&&(Child.getNodeName().equalsIgnoreCase("startevent")||Child.getNodeName().equalsIgnoreCase("endevent")))
            {
              AddEvent(Child,ALC);
            }
            if(Child!=null)
             {
               Child=Child.getNextSibling();
               ConstructALC(Child, ALC);
             }
             return ALC;
      }
     public static void AddEvent(Node Child, Element E)
      {
        for(int d=0;d<E.getChildNodes().getLength();d++)
         {
           Node O=E.getChildNodes().item(d);
           if(O.getNodeType()==Node.ELEMENT_NODE)
            {
              Element State=document.createElement("State");
              O.appendChild(State);
              State.setAttribute("in", Child.getAttributes().getNamedItem("name").getNodeValue());
            }
         }
     }
    public static void AddNewGateway(Node Child, Element ALC,int count)
     {
      for(int i=0;i<E.getChildNodes().getLength();i++)
        {
          if(E.getChildNodes().item(i).getNodeType()==Node.ELEMENT_NODE)
           {
             if(count==0)
               {
                 gnode=document.createElement(Child.getNodeName());
                 gnode.setAttribute("name", Child.getAttributes().getNamedItem("name").getNodeValue());
                 E.getChildNodes().item(i).appendChild(gnode);
               }
             else 
               {
                 gnode=document.createElement(Child.getNodeName());
                 gnode.setAttribute("name", Child.getAttributes().getNamedItem("name").getNodeValue());
                 Node last=E.getChildNodes().item(i).getLastChild(); // object
                 System.out.println("GGGGGGGGGG"+last.getNodeName());
                 int test=0;
                 Node O=E.getChildNodes().item(i);
                 last=TestNode(last,gnode,O,test);
               }
           }
        }
      }
    public static Node TestNode(Node last,Node gnode, Node O,int test)
      {
       if(last.getNodeName().equalsIgnoreCase("gateway"))
          {
            test=test+1;
            if(count==test)
              {
                 last.getLastChild().appendChild(gnode);
              }
            else
              {
                while(last.getLastChild()!=null)
                 {
                   last=last.getLastChild();
                 }
                 last=TestNode(last,gnode,O,test);
             }
          }
       else if(last.getNodeName().equalsIgnoreCase("State"))
          {
            last.getParentNode().appendChild(gnode);
          }
       else
          {
            last.appendChild(gnode);
          }
          return last;
      }   
    public static void TestIO(Node a, Element ALC)
      {
        State=null;
        if(a.getNodeType()==Node.ELEMENT_NODE)
          {
            if(a.hasAttributes())
             {
               AddStates(a, ALC, State);
             }
            else if(a.hasChildNodes())
              {
                for(int i=0;i<a.getChildNodes().getLength();i++)
                  {
                    if(a.getChildNodes().item(i).getNodeType()==Node.ELEMENT_NODE)
                      {
                        int c=0;
                        String id=a.getChildNodes().item(i).getAttributes().getNamedItem("id").getNodeValue();
                        String st=a.getChildNodes().item(i).getAttributes().getNamedItem("state").getNodeValue();
                        for(int j=0;j<a.getChildNodes().getLength();j++)
                          {
                            if(a.getChildNodes().item(j).getNodeType()==Node.ELEMENT_NODE)
                              {
                                if(a.getChildNodes().item(j).getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(id))
                                  {
                                    c=c+1;
                                  }
                              }
                          }
                          if(c==1)
                            {
                              TestIO(a.getChildNodes().item(i),ALC); 
                            }
                        }
                    }
                 }
              }
           }
    public static void AddStates(Node a,Element ALC, Element State)
      {
         String id=a.getAttributes().getNamedItem("id").getNodeValue();
         if(ALC.getNodeName().equalsIgnoreCase("ArtifactLifeCycles"))
           {
             for(int i=0;i<E.getChildNodes().getLength();i++)
              {
                if(E.getChildNodes().item(i).getNodeType()==Node.ELEMENT_NODE)
                 {
                   if(E.getChildNodes().item(i).getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(id))
                     {
                       State=document.createElement("State");
                       E.getChildNodes().item(i).appendChild(State);
                       State.setAttribute("in", a.getAttributes().getNamedItem("state").getNodeValue());
                     }
                 }
              }
           }
         else if (ALC.getNodeName().equalsIgnoreCase("branch")||ALC.getNodeName().equalsIgnoreCase("state"))
            {
              for(int i=0;i<E.getChildNodes().getLength();i++)
               {
                 if(E.getChildNodes().item(i).getNodeType()==Node.ELEMENT_NODE)
                   {
                    if(E.getChildNodes().item(i).getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(id))
                      {
                        State=document.createElement("State");
                        State.setAttribute("in", a.getAttributes().getNamedItem("state").getNodeValue());
                        Node last=E.getChildNodes().item(i).getLastChild();
                        Node l=null;
                        int jp=0;
                        while(last!=null)
                         {
                           if(last.getNodeName().equalsIgnoreCase("gateway"))
                             {
                               jp=jp+1;
                               if(jp==count)
                                {
                                  l=last;
                                }
                             }
                             last=last.getLastChild();
                         }
                        if(l.getNodeName().equalsIgnoreCase("gateway"))
                         {
                           l.getLastChild().appendChild(State);
                         }
                      }
                   }
               }
            } 
      }
   }
   
   
  
   
           
       



  




